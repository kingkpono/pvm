<?php

namespace App;

use Illuminate\Database\Eloquent\Model;


class WalletTransactions extends Model
{
   /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'email','amount','txn_type','transactionRef','requestReference','customerId','biller'
    ];


    public function getTransactions($email)
    {
    	$wallet_tns=WalletTransactions::where('email',$email)->get();
    	return $wallet_tns;
    }

    public function getTransactionsCnt($email)
    {
    	$wallet_tns=WalletTransactions::where('email',$email)->get()->count();
    	
    	return $wallet_tns;
    }

}
