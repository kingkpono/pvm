<?php

namespace App\Mail;
use Illuminate\Bus\Queueable;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;
use Illuminate\Contracts\Queue\ShouldQueue;
class WelcomeMail extends Mailable
{
    use Queueable, SerializesModels;
public $data;
public function __construct($data)
    {
        $this->data = $data;
    }
public function build()
    {
        $address = 'wrallous@gmail.com';
        $subject = 'Welcome to Wrallo';
        $name = 'Wrallo Team';
        
        return $this->view('email.welcome')
                    ->from($address, $name)
                    ->cc($address, $name)
                    ->bcc($address, $name)
                    ->replyTo($address, $name)
                    ->subject($subject)
                    ->with([ 'message' => 'Test' ]);
    
      }
}