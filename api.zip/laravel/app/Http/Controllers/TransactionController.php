<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Wallet;
use App\WalletTransactions;
use Auth;
use Symfony\Component\HttpFoundation\Response;
use Illuminate\Support\Facades\DB;
use Validator;

class TransactionController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('jwt');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index()
    {
        $wallet=new Wallet();   
        $wallet_bal=$wallet->getBalance(Auth::user()->email);

        $data['wallet_balance']=$wallet_bal;

        return view('airtel',$data);
    }

function getDataPaymentItems(Request $request)
{
    return $this->paymentItems($this->getBillers($request->input('network')));
}
function paymentItems($billerId)
{
   
    
    $httpMethod="GET";
$url=urlencode("https://saturn.interswitchng.com/api/v2/quickteller/billers/".$billerId."/paymentitems");
$timeStamp=time();
$nonce = uniqid(mt_rand(), true);

$client="IKIAC1663DFCD63DA7AB5EF1F16AAFA461F3F2FED693";
$secret="145bgJDSc4rqDvw2yzL6UB0shUiHfimQO1TxM3XKxGQ=";
$authorization = "InterswitchAuth"." ".base64_encode($client);
$cipherSig=$httpMethod.'&'.$url.'&'.$timeStamp.'&'.$nonce.'&'.$client.'&'.$secret;
$base=sha1($cipherSig,true);
$signature=base64_encode($base);
    $ch = curl_init("https://saturn.interswitchng.com/api/v2/quickteller/billers/".$billerId."/paymentitems");
curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "GET");
curl_setopt($ch,CURLOPT_RETURNTRANSFER,1);
curl_setopt($ch, CURLOPT_HTTPHEADER,
    array(
        'Content-Type:application/json',
         'Accept:application/json',
         'Timestamp:'.$timeStamp,
         'Nonce:'.$nonce,
         'Signature:'.$signature,
         'SignatureMethod: SHA1',
         'Authorization:'.$authorization
    )
);

$response= json_decode(curl_exec($ch));

if(isset($response->error))
{
    $errorObject=$response->error;
     return response()->json([
         'status'=>'failed',
         'message'=>$errorObject->message
         ], 400);

}
if(isset($response->paymentitems))
{
 
 $paymentItems=[];
 
 foreach($response->paymentitems as $paymentItem)
 {
     $paymentItemObj['amount']=$paymentItem->amount/100;
    $paymentItemObj['paymentitemname']=$paymentItem->paymentitemname;
    $paymentItemObj['paymentCode']=$paymentItem->paymentCode;

     $paymentItems[]= $paymentItemObj;

 }
     return response()->json([
         'status'=>'success',
         'data'=>[
              $paymentItems
             ]
         ], 201);
}
 


 //return response()->json($response, 201);
 
 

}


function paymentAdviceData(Request $request)
{

if(!Auth::check())
    {
         return response()->json([
                'status'=>'error',
                'message'=>'Token not valid' ],
                400);
    }
  

 $mobile_number=$request->input('mobile_number');
 $paymentCode=$request->input('paymentCode');
 $amount=$request->input('amount')*100;
$email=auth()->user()->email;
$validator = Validator::make($request->all(), [
            'amount'=>'required',
            'mobile_number'=>'required',
        ]);

         if($validator->fails()){
            return response()->json([
                'status'=>'error',
                'message'=>$this->getErrorMsg($validator->errors()) ],
                400);
        }
        
    

$httpMethod="POST";
$url=urlencode("https://saturn.interswitchng.com/api/v2/quickteller/payments/advices");
$timeStamp=time();
$nonce =uniqid();
$client="IKIAC1663DFCD63DA7AB5EF1F16AAFA461F3F2FED693";
$secret="145bgJDSc4rqDvw2yzL6UB0shUiHfimQO1TxM3XKxGQ=";
$authorization = "InterswitchAuth"." ".base64_encode($client);
$cipherSig=$httpMethod.'&'.$url.'&'.$timeStamp.'&'.$nonce.'&'.$client.'&'.$secret;
$base=sha1($cipherSig,true);
$signature=base64_encode($base);
$ch = curl_init("https://saturn.interswitchng.com/api/v2/quickteller/payments/advices");

$customerId=$mobile_number;
$requestReference='1969'.$timeStamp;
$postData='{
"terminalId":"3ARW0001",
"paymentCode":"'.$paymentCode.'",
"customerId":"'.$customerId.'",
"customerMobile":"'.$mobile_number.'",
"customerEmail":"'.$email.'",
"amount":"'.($amount).'",
"requestReference":"'.$requestReference.'"
}';

curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
curl_setopt($ch,CURLOPT_RETURNTRANSFER,1);
curl_setopt($ch, CURLOPT_POSTFIELDS, $postData);           

curl_setopt($ch, CURLOPT_HTTPHEADER,
    array(
        'Content-Type:application/json',
         'Accept:application/json',
         'Timestamp:'.$timeStamp,
         'Nonce:'.$nonce,
         'Signature:'.$signature,
         'SignatureMethod: SHA1',
         'Authorization:'.$authorization
    )
);



/*
$httpCode= curl_getinfo($ch, CURLINFO_HTTP_CODE);

$response= json_decode(curl_exec($ch));

if(isset($response->error))
{
    $errorObject=$response->error;
     return response()->json([
         'status'=>'failed',
         'message'=>$errorObject->message
         ], 400);

}
*/

$this->logTxn($email,$amount,"Data",$customerId,$requestReference,"ARW|Web|3ARW0001|MTN|091021091844|QYVPEDVU");

return response()->json([
    'status'=>'success',
      'transactionRef'=> 'ARW|Web|3ARW0001|MTN|091021091844|QYVPEDVU',
    'message'=>'Sucessful'
    
    ], 201);


}


function paymentAdvice(Request $request)
{
if(!Auth::check())
    {
         return response()->json([
                'status'=>'error',
                'message'=>'Token not valid' ],
                400);
    }

 $mobile_number=$request->input('mobile_number');
  $network=$request->input('networkr');

 $paymentCode=$this->getPaymentCode( $network);
 $amount=$request->input('amount')*100;
$email=auth()->user()->email;
$validator = Validator::make($request->all(), [
            'amount'=>'required',
            'mobile_number'=>'required'
        ]);

         if($validator->fails()){
            return response()->json([
                'status'=>'error',
                'message'=>$this->getErrorMsg($validator->errors()) ],
                400);
        }
        
    

$httpMethod="POST";
$url=urlencode("https://saturn.interswitchng.com/api/v2/quickteller/payments/advices");
$timeStamp=time();
$nonce =uniqid();
$client="IKIAC1663DFCD63DA7AB5EF1F16AAFA461F3F2FED693";
$secret="145bgJDSc4rqDvw2yzL6UB0shUiHfimQO1TxM3XKxGQ=";
$authorization = "InterswitchAuth"." ".base64_encode($client);
$cipherSig=$httpMethod.'&'.$url.'&'.$timeStamp.'&'.$nonce.'&'.$client.'&'.$secret;
$base=sha1($cipherSig,true);
$signature=base64_encode($base);
$ch = curl_init("https://saturn.interswitchng.com/api/v2/quickteller/payments/advices");

$customerId=$mobile_number;
$requestReference='1969'.$timeStamp;
$postData='{
"terminalId":"3ARW0001",
"paymentCode":"'.$paymentCode.'",
"customerId":"'.$customerId.'",
"customerMobile":"'.$mobile_number.'",
"customerEmail":"'.$email.'",
"amount":"'.($amount).'",
"requestReference":"'.$requestReference.'"
}';

curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
curl_setopt($ch,CURLOPT_RETURNTRANSFER,1);
curl_setopt($ch, CURLOPT_POSTFIELDS, $postData);           

curl_setopt($ch, CURLOPT_HTTPHEADER,
    array(
        'Content-Type:application/json',
         'Accept:application/json',
         'Timestamp:'.$timeStamp,
         'Nonce:'.$nonce,
         'Signature:'.$signature,
         'SignatureMethod: SHA1',
         'Authorization:'.$authorization
    )
);




//$httpCode= curl_getinfo($ch, CURLINFO_HTTP_CODE);

//$response= json_decode(curl_exec($ch));

/*if(isset($response->error))
{
    $errorObject=$response->error;
     return response()->json([
         'status'=>'failed',
         'message'=>$errorObject->message
         ], 200);

}
*/
$this->logTxn($email,$amount,"Airtime",$customerId,$requestReference,"ARW|Web|3ARW0001|MTN|091021091844|QYVPEDVU");

return response()->json([
    'status'=>'success',
      'transactionRef'=> 'ARW|Web|3ARW0001|MTN|091021091844|QYVPEDVU',
    'message'=>'Sucessful'
    
    ], 201);


}


  
             
             
function paymentAdvice2(Request $request)
{

if(!Auth::check())
    {
         return response()->json([
                'status'=>'error',
                'message'=>'Token not valid' ],
                400);
    }

 $customerId=$request->input('customerid');

 $paymentCode=$request->input('paymentCode');
 $amount=$request->input('amount')*100;
 
$email=auth()->user()->email;
$validator = Validator::make($request->all(), [
            'amount'=>'required',
            'customerid'=>'required',
            'paymentCode'=>'required'
        ]);

         if($validator->fails()){
            return response()->json([
                'status'=>'error',
                'message'=>$this->getErrorMsg($validator->errors()) ],
                400);
        }
      

$httpMethod="POST";
$url=urlencode("https://saturn.interswitchng.com/api/v2/quickteller/payments/advices");
$timeStamp=time();
$nonce =uniqid();
$client="IKIAC1663DFCD63DA7AB5EF1F16AAFA461F3F2FED693";
$secret="145bgJDSc4rqDvw2yzL6UB0shUiHfimQO1TxM3XKxGQ=";
$authorization = "InterswitchAuth"." ".base64_encode($client);
$cipherSig=$httpMethod.'&'.$url.'&'.$timeStamp.'&'.$nonce.'&'.$client.'&'.$secret;
$base=sha1($cipherSig,true);
$signature=base64_encode($base);
$ch = curl_init("https://saturn.interswitchng.com/api/v2/quickteller/payments/advices");

$requestReference='1969'.$timeStamp;
$postData='{
"terminalId":"3ARW0001",
"paymentCode":"'.$paymentCode.'",
"customerId":"'.$customerId.'",
"customerMobile":"'.auth()->user()->phone.'",
"customerEmail":"'.$email.'",
"amount":"'.($amount).'",
"requestReference":"'.$requestReference.'"
}';

curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
curl_setopt($ch,CURLOPT_RETURNTRANSFER,1);
curl_setopt($ch, CURLOPT_POSTFIELDS, $postData);           

curl_setopt($ch, CURLOPT_HTTPHEADER,
    array(
        'Content-Type:application/json',
         'Accept:application/json',
         'Timestamp:'.$timeStamp,
         'Nonce:'.$nonce,
         'Signature:'.$signature,
         'SignatureMethod: SHA1',
         'Authorization:'.$authorization
    )
);



 

/*$this->logTxn($email,$amount,"TV",$customerId,$requestReference,"ARW|Web|3ARW0001|GTV|091021091844|QYVPEDVU");

 return response()->json([
    'status'=>'success',
      'transactionRef'=> 'ARW|Web|3ARW0001|GTV|091021091844|QYVPEDVU',
    'message'=>'Sucessful'
    
    ], 201);
    */


$httpCode= curl_getinfo($ch, CURLINFO_HTTP_CODE);

$response= json_decode(curl_exec($ch));

if(isset($response->error))
{
    $errorObject=$response->error;
     return response()->json([
         'status'=>'failed',
         'message'=>$errorObject->message
         ], 200);

}else if($response->responseCode==9000){
    
    return response()->json([
    'status'=>'success',
    'transactionRef'=>$response->transactionRef,
    'message'=>$response->responseCodeGrouping
    
    ], 201);
}
    



 return response()->json($response, 201);

}


public function getTvBillers()
{
    $billers=DB::table('biller')
    ->select('billerid','billername')
    ->where('categoryid','=',2)
    ->orderBy('id','DESC')->get();
    
      return response()->json(
              ['status'=>'success',
            'data'=> $billers]);
            
             
}

public function fetchTxns()
{
    if(!Auth::check())
    {
         return response()->json([
                'status'=>'error',
                'message'=>'Token not valid' ],
                400);
    }
    
    $txns=DB::table('wallet_transactions')
    ->select('*')
    ->where('email','=',auth()->user()->email)
    ->orderBy('id','DESC')->get();
    
      return response()->json(
              ['status'=>'success',
            'data'=> $txns]);
            
             
}

public function getElectricBillers()
{
    $billers=DB::table('biller')
    ->select('billerid','billername')
    ->where('categoryid','=',1)
    ->orderBy('id','DESC')->get();
    
      return response()->json(
              ['status'=>'success',
            'data'=> $billers]);
            
             
}
public function getInternetBillers()
{
    $billers=DB::table('biller')
    ->select('billerid','billername')
    ->where('categoryid','=',5)
    ->orderBy('id','DESC')->get();
    
      return response()->json(
              ['status'=>'success',
            'data'=> $billers]);
            
             
}



public function getBetBillers()
{
    $billers=DB::table('biller')
    ->select('billerid','billername')
    ->where('categoryid','=',41)
    ->orderBy('id','DESC')->get();
    
      return response()->json(
              ['status'=>'success',
            'data'=> $billers]);
            
             
}

public function getAirtimeBillers()
{    
   
      
    $networks=['biller'=>'mtn','paymentCode'=>90304,'biller'=>'airtel','paymentCode'=>90106,'biller'=>'glo','paymentCode'=>91309,'biller'=>'9mobile','paymentCode'=>90806];
     return response()->json(
              ['status'=>'success',
            'data'=> $networks]);
    
    
            
             
}

public function getPaymentCode($number)
{
   

     
     if($number=="MTN")
     {
         return 90304;
     }
      if($number=="AIRTEL")
     {
         return 90106;
     } 
      if($number=="GLO")
     {
         return 91309;
     }
     
    if($number=="9MOBILE")
    {
         return 90806;
      }
}

public function getBillers($number)
{
    
     
     if($number=="MTN")
     {
         return 348;
     }
     if($number=="AIRTEL" )
     {
         return 923;
     } 
     if($number=="GLO")
     {
         return 3070;
     }
     
      if($number=="9MOBILE" )
      {
         return 2944;
      }
}


  protected function getErrorMsg($errors)
    {
        
        $out="";
        foreach ($errors->all() as $error)
        {
         $out.= $error;
       
        
        }
        return $out;
    }
    
    
    
function validateCustomer(Request $request)
{
    
 $customerId=$request->input('customerid');

 $paymentCode=$request->input('paymentCode');


$validator = Validator::make($request->all(), [
        
            'customerid'=>'required',
            'paymentCode'=>'required'
        ]);

         if($validator->fails()){
            return response()->json([
                'status'=>'error',
                'message'=>$this->getErrorMsg($validator->errors()) ],
                400);
        }
    $httpMethod="POST";
$url=urlencode("https://saturn.interswitchng.com/api/v2/quickteller/customers/validations");
$timeStamp=time();
$nonce =uniqid();
$client="IKIAC1663DFCD63DA7AB5EF1F16AAFA461F3F2FED693";
$secret="145bgJDSc4rqDvw2yzL6UB0shUiHfimQO1TxM3XKxGQ=";
$authorization = "InterswitchAuth"." ".base64_encode($client);
$cipherSig=$httpMethod.'&'.$url.'&'.$timeStamp.'&'.$nonce.'&'.$client.'&'.$secret;
$base=sha1($cipherSig,true);
$signature=base64_encode($base);
$ch = curl_init("https://saturn.interswitchng.com/api/v2/quickteller/customers/validations");

$postData='{
  "customers": [
    {
      "customerId": "'.$customerId.'",
      "paymentCode": "'.$paymentCode.'"
    }
  ]
} 
';
curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
curl_setopt($ch,CURLOPT_RETURNTRANSFER,1);
curl_setopt($ch, CURLOPT_POSTFIELDS, $postData);           

curl_setopt($ch, CURLOPT_HTTPHEADER,
    array(
        'Content-Type:application/json',
         'Accept:application/json',
         'Timestamp:'.$timeStamp,
         'Nonce:'.$nonce,
         'Signature:'.$signature,
         'SignatureMethod: SHA1',
         'Authorization:'.$authorization
    )
);

$response= json_decode(curl_exec($ch));
if(isset($response->error))
{
    $errorObject=$response->error;
     return response()->json([
         'status'=>'failed',
         'message'=>$errorObject->message
         ], 200);

}
if(isset($response->error))
{
    $errorObject=$response->error;
     return response()->json([
         'status'=>'failed',
         'message'=>$errorObject->message
         ], 200);

}
 $csRes=$response->{'Customers'}[0];
        
        @$cusAmountType=$csRes->{'amountType'};
        @$amount=$csRes->{'amount'};
        @$cusResponseCode=$csRes->{'responseCode'};
        @$cusResponseDescription=$csRes->{'responseDescription'};

        @$fullName=isset($csRes->{'fullName'})?$csRes->{'fullName'}:$csRes->{'responseDescription'};
        @$paymentCode=$csRes->{'paymentCode'};
        @$customerId=$csRes->{'customerId'};

        
        if($cusAmountType==0)
        {
         $amount=$amount;
        }else if($cusAmountType==1)
        {
            $amount=$amount;
        }else if($cusAmountType==2)
        {
            $amount=$amount+1;
        }
        else if($cusAmountType==3)
        {
            $amount=$amount;
        }
     
         
         if($cusResponseCode==90000)
         { return response()->json([
         'status'=>'success',
         'data'=>[
             
              'fullName'=>$fullName,
              'paymentCode'=>$paymentCode,
              'amount'=>$amount/100,
              'customerid'=>$customerId
             ]
         ], 201);
         }else{
             return response()->json([
         'status'=>'failed',
              'message'=>$cusResponseDescription
           
            
         ],400) ;
         
             
         }
           


}


             
             
function paymentAdviceElect(Request $request)
{
 if(!Auth::check())
    {
         return response()->json([
                'status'=>'error',
                'message'=>'Token not valid' ],
                400);
    }

 $customerId=$request->input('customerid');
 $paymentCode=$request->input('paymentCode');
 $amount=$request->input('amount');
 $amount=$amount*100;
 
$email=auth()->user()->email;
$validator = Validator::make($request->all(), [
            'amount'=>'required',
            'customerid'=>'required',
            'paymentCode'=>'required'
        ]);

         if($validator->fails()){
            return response()->json([
                'status'=>'error',
                'message'=>$this->getErrorMsg($validator->errors()) ],
                400);
        }
      

$httpMethod="POST";
$url=urlencode("https://saturn.interswitchng.com/api/v2/quickteller/payments/advices");
$timeStamp=time();
$nonce =uniqid();
$client="IKIAC1663DFCD63DA7AB5EF1F16AAFA461F3F2FED693";
$secret="145bgJDSc4rqDvw2yzL6UB0shUiHfimQO1TxM3XKxGQ=";
$authorization = "InterswitchAuth"." ".base64_encode($client);
$cipherSig=$httpMethod.'&'.$url.'&'.$timeStamp.'&'.$nonce.'&'.$client.'&'.$secret;
$base=sha1($cipherSig,true);
$signature=base64_encode($base);
$ch = curl_init("https://saturn.interswitchng.com/api/v2/quickteller/payments/advices");

$requestReference='1969'.$timeStamp;
$postData='{
"terminalId":"3ARW0001",
"paymentCode":"'.$paymentCode.'",
"customerId":"'.$customerId.'",
"customerMobile":"'.auth()->user()->phone.'",
"customerEmail":"'.$email.'",
"amount":"'.($amount).'",
"requestReference":"'.$requestReference.'"
}';

curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
curl_setopt($ch,CURLOPT_RETURNTRANSFER,1);
curl_setopt($ch, CURLOPT_POSTFIELDS, $postData);           

curl_setopt($ch, CURLOPT_HTTPHEADER,
    array(
        'Content-Type:application/json',
         'Accept:application/json',
         'Timestamp:'.$timeStamp,
         'Nonce:'.$nonce,
         'Signature:'.$signature,
         'SignatureMethod: SHA1',
         'Authorization:'.$authorization
    )
);

//his->logTxn($email,$amount,"Electricity",$customerId,$requestReference,"ARW|Web|3ARW0001|IBDP|091021103125|JECPN

$httpCode= curl_getinfo($ch, CURLINFO_HTTP_CODE);

$response= json_decode(curl_exec($ch));

if(isset($response->error))
{
    $errorObject=$response->error;
     return response()->json([
         'status'=>'failed',
         'message'=>$errorObject->message
         ], 200);

}else if($response->responseCodeGrouping=="SUCCESSFUL"){
    
    return response()->json([
    'status'=>'success',
    'transactionRef'=>$response->transactionRef,
    'rechargePin'=>$response->rechargePIN,
    'message'=>$response->responseCodeGrouping
    
    ], 201);
}
   


 return response()->json($response, 201);

}
    
    
    
                 
function paymentAdviceBet(Request $request)
{
if(!Auth::check())
    {
         return response()->json([
                'status'=>'error',
                'message'=>'Token not valid' ],
                400);
    }

 $customerId=$request->input('customerid');

 $paymentCode=$request->input('paymentCode');
 $amount=$request->input('amount')*100;
 
$email=auth()->user()->email;
$validator = Validator::make($request->all(), [
            'amount'=>'required',
            'customerid'=>'required',
            'paymentCode'=>'required'
        ]);

         if($validator->fails()){
            return response()->json([
                'status'=>'error',
                'message'=>$this->getErrorMsg($validator->errors()) ],
                400);
        }
      

$httpMethod="POST";
$url=urlencode("https://saturn.interswitchng.com/api/v2/quickteller/payments/advices");
$timeStamp=time();
$nonce =uniqid();
$client="IKIAC1663DFCD63DA7AB5EF1F16AAFA461F3F2FED693";
$secret="145bgJDSc4rqDvw2yzL6UB0shUiHfimQO1TxM3XKxGQ=";
$authorization = "InterswitchAuth"." ".base64_encode($client);
$cipherSig=$httpMethod.'&'.$url.'&'.$timeStamp.'&'.$nonce.'&'.$client.'&'.$secret;
$base=sha1($cipherSig,true);
$signature=base64_encode($base);
$ch = curl_init("https://saturn.interswitchng.com/api/v2/quickteller/payments/advices");

$requestReference='1969'.$timeStamp;
$postData='{
"terminalId":"3ARW0001",
"paymentCode":"'.$paymentCode.'",
"customerId":"'.$customerId.'",
"customerMobile":"'.auth()->user()->phone.'",
"customerEmail":"'.$email.'",
"amount":"'.($amount).'",
"requestReference":"'.$requestReference.'"
}';

curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
curl_setopt($ch,CURLOPT_RETURNTRANSFER,1);
curl_setopt($ch, CURLOPT_POSTFIELDS, $postData);           

curl_setopt($ch, CURLOPT_HTTPHEADER,
    array(
        'Content-Type:application/json',
         'Accept:application/json',
         'Timestamp:'.$timeStamp,
         'Nonce:'.$nonce,
         'Signature:'.$signature,
         'SignatureMethod: SHA1',
         'Authorization:'.$authorization
    )
);



$this->logTxn($email,$amount,"Betting",$customerId,$requestReference,"ARW|Web|3ARW0001|NRBT|091021113003|XDAA3KNY");



  return response()->json([
    'status'=>'success',
      'transactionRef'=> 'ARW|Web|3ARW0001|NRBT|091021113003|XDAA3KNY',
    'message'=>'Sucessful'
    
    ], 201);
/*
$httpCode= curl_getinfo($ch, CURLINFO_HTTP_CODE);

$response= json_decode(curl_exec($ch));

if(isset($response->error))
{
    $errorObject=$response->error;
     return response()->json([
         'status'=>'failed',
         'message'=>$errorObject->message
         ], 200);

}else if($response->responseCode==9000){
    
    return response()->json([
    'status'=>'success',
    'transactionRef'=>$response->transactionRef,
    'message'=>$response->responseCodeGrouping
    
    ], 201);
}
    
}
*/
 return response()->json($response, 201);

}
                 
function paymentAdviceInternet(Request $request)
{
 
if(!Auth::check())
    {
         return response()->json([
                'status'=>'error',
                'message'=>'Token not valid' ],
                400);
    }
 $customerId=$request->input('customerid');

 $paymentCode=$request->input('paymentCode');
 $amount=$request->input('amount')*100;
 
$email=auth()->user()->email;
$validator = Validator::make($request->all(), [
            'amount'=>'required',
            'customerid'=>'required',
            'paymentCode'=>'required'
        ]);

         if($validator->fails()){
            return response()->json([
                'status'=>'error',
                'message'=>$this->getErrorMsg($validator->errors()) ],
                400);
        }
      

$httpMethod="POST";
$url=urlencode("https://saturn.interswitchng.com/api/v2/quickteller/payments/advices");
$timeStamp=time();
$nonce =uniqid();
$client="IKIAC1663DFCD63DA7AB5EF1F16AAFA461F3F2FED693";
$secret="145bgJDSc4rqDvw2yzL6UB0shUiHfimQO1TxM3XKxGQ=";
$authorization = "InterswitchAuth"." ".base64_encode($client);
$cipherSig=$httpMethod.'&'.$url.'&'.$timeStamp.'&'.$nonce.'&'.$client.'&'.$secret;
$base=sha1($cipherSig,true);
$signature=base64_encode($base);
$ch = curl_init("https://saturn.interswitchng.com/api/v2/quickteller/payments/advices");

$requestReference='1969'.$timeStamp;
$postData='{
"terminalId":"3ARW0001",
"paymentCode":"'.$paymentCode.'",
"customerId":"'.$customerId.'",
"customerMobile":"'.auth()->user()->phone.'",
"customerEmail":"'.$email.'",
"amount":"'.($amount).'",
"requestReference":"'.$requestReference.'"
}';

curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
curl_setopt($ch,CURLOPT_RETURNTRANSFER,1);
curl_setopt($ch, CURLOPT_POSTFIELDS, $postData);           

curl_setopt($ch, CURLOPT_HTTPHEADER,
    array(
        'Content-Type:application/json',
         'Accept:application/json',
         'Timestamp:'.$timeStamp,
         'Nonce:'.$nonce,
         'Signature:'.$signature,
         'SignatureMethod: SHA1',
         'Authorization:'.$authorization
    )
);



 


$this->logTxn($email,$amount,"Internet",$customerId,$requestReference,"ARW|Web|3ARW0001|SMILE|091021113003|XDAA3KNY");



  return response()->json([
    'status'=>'success',
      'transactionRef'=> 'ARW|Web|3ARW0001|SMILE|091021113003|XDAA3KNY',
    'message'=>'Sucessful'
    
    ], 201);
/*
$httpCode= curl_getinfo($ch, CURLINFO_HTTP_CODE);

$response= json_decode(curl_exec($ch));

if(isset($response->error))
{
    $errorObject=$response->error;
     return response()->json([
         'status'=>'failed',
         'message'=>$errorObject->message
         ], 200);

}else if($response->responseCode==9000){
    
    return response()->json([
    'status'=>'success',
    'transactionRef'=>$response->transactionRef,
    'message'=>$response->responseCodeGrouping
    
    ], 201);
}
    
}
*/
 return response()->json($response, 201);

}


public function getWalletBalance()
{
    try{
    $wallet =new Wallet();
    
    $balance=$wallet->getBalance(auth()->user()->email);
    
     return response()->json([
    'status'=>'success',
    'data'=>['balance'=>$balance]
    
    ], 201);
    }catch(\Exception $e)
    {
        
          return response()->json([
    'status'=>'error',
    'message'=>'Internal Server  Error'
    ], 401);
    }
    
}

public function creditWallet(Request $request)
{
    
    $validator = Validator::make($request->all(), [
            'amount'=>'required'
        ]);

         if($validator->fails()){
            return response()->json([
                'status'=>'error',
                'message'=>$this->getErrorMsg($validator->errors()) ],
                400);
        }
    try{
    $amount=$request->input('amount');
    $wallet =new Wallet();
    
    $wallet->credit([
        'email'=>
        auth()->user()->email,
        'amount'=>       $amount]);
    $balance=$wallet->getBalance(auth()->user()->email);

     return response()->json([
    'status'=>'success',
    'data'=>['balance'=>$balance]
    
    ], 201);
    }catch(\Exception $e)
    {
     
          return response()->json([
    'status'=>'error',
    'message'=>'Internal Server  Error'
    ], 401);
    }
        
    
    
}

public function debitWallet(Request $request)
{
    
    $validator = Validator::make($request->all(), [
            'amount'=>'required'
        ]);

         if($validator->fails()){
            return response()->json([
                'status'=>'error',
                'message'=>$this->getErrorMsg($validator->errors()) ],
                400);
        }
    try{
    $amount=$request->input('amount');
    $wallet =new Wallet();
    
    $wallet->debit([
        'email'=>
        auth()->user()->email,
        'amount'=>       $amount]);
    $balance=$wallet->getBalance(auth()->user()->email);

     return response()->json([
    'status'=>'success',
    'data'=>['balance'=>$balance]
    
    ], 201);
    }catch(\Exception $e)
    {
     
          return response()->json([
    'status'=>'error',
    'message'=>'Internal Server  Error'
    ], 401);
    }
        
    
    
}


protected function logTxn($email,$amount,$type,$customerId,$requestReference,$transactionRef)
{
   $biller=explode("|",$transactionRef);
  
   
    WalletTransactions::create([
            'email'=>$email,
            'txn_type'=>$type,
            'transactionRef'=> $transactionRef,
            'requestReference'=>$requestReference,
          'customerId'=>$customerId,
            'biller'=>$biller[3],
            'amount'=>$amount,
            'email'=>$email
        ]);
     $wallet=new Wallet();
     $wallet->debit([ 'email'=>
        $email,
        'amount'=>       $amount]);
}


           
}