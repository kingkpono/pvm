<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Wallet;
use Auth;

class AddFundsController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }
    

     /**
     * Get a validator for an incoming registration request.
     *
     * @param  array  $data
     * @return \Illuminate\Contracts\Validation\Validator
     */
    protected function validator(array $data)
    {
        return Validator::make($data, [
            'amount' => ['required', 'number', 'min:3'],
           
           
        ]);
    }
    /**
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index()
    {
       $wallet=new Wallet();
        $wallet_bal=$wallet->getBalance(Auth::user()->email);

        $data['wallet_balance']=$wallet_bal;

        return view('addfunds',$data);
    }



 /**
     *
     * @param  array  $data
     */
    public function addfunds(Request $request)
    {
    	$email=Auth::user()->email;

      $amount=$request->input('amount');
$curl = curl_init();


// url to go to after payment
$callback_url = 'https://wrallo.us/paystackresponse'; 

curl_setopt_array($curl, array(
  CURLOPT_URL => "https://api.paystack.co/transaction/initialize",
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_CUSTOMREQUEST => "POST",
  CURLOPT_POSTFIELDS => json_encode([
    'amount'=>$amount*100,
    'email'=>Auth::user()->email,
    'callback_url' => $callback_url
  ]),
  CURLOPT_HTTPHEADER => [
    "authorization: Bearer sk_test_78e2ac5eaf4b6c94ca9294605bf0ac596b1a3fe4",
    "content-type: application/json",
    "cache-control: no-cache"
  ],
));

$response = curl_exec($curl);
$err = curl_error($curl);

if($err){
  $errorMsg="There was an error contacting Paystack";
}

$tranx = json_decode($response, true);

if(!$tranx['status']){
    $errorMsg.="</br>".$tranx['message'];

}

if(empty($errorMsg)){
	return redirect($tranx['data']['authorization_url']);

}else{
	$data['message']=$errorMsg;
	return view('addfunds',$data);
}


    }


    public function callback(Request $request)
    {

  $reference=$request->input('reference');
$curl = curl_init();
if(!$reference){
 $error='No reference supplied';
}

curl_setopt_array($curl, array(
  CURLOPT_URL => "https://api.paystack.co/transaction/verify/" . rawurlencode($reference),
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_HTTPHEADER => [
    "accept: application/json",
    "authorization: Bearer sk_test_78e2ac5eaf4b6c94ca9294605bf0ac596b1a3fe4",
    "cache-control: no-cache"
  ],
));

$response = curl_exec($curl);
$err = curl_error($curl);

if($err){
    // there was an error contacting the Paystack API
  $error='Curl returned error: ' . $err;
}

$tranx = json_decode($response);

if(!$tranx->status){
  // there was an error from the API
 $error='API returned error: ' . $tranx->message;
}

if('success' == $tranx->data->status){
  if(Auth::user()->email==$tranx->data->customer->email)
  {
  $wallet=new Wallet();
  $wallet->credit([
  	'email'=>Auth::user()->email,
  	'balance'=>$tranx->data->amount/100]);
 
  return redirect("/home?wallet_add_funds=success");
  }
}else{
    return redirect("/home?wallet_add_funds=failure&message=".$tranx->message);
 
}
    }
    
    

 }