<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Wallet;
use App\WalletTransactions;
use Auth;

class StartimesController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index()
    {
        $wallet=new Wallet();   
        $wallet_bal=$wallet->getBalance(Auth::user()->email);

        $data['wallet_balance']=$wallet_bal;

        return view('startimes',$data);
    }
}

