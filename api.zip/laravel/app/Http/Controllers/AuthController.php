<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Auth;
use App\User;
use Validator;
use Illuminate\Support\Str;
use JWTAuth;
use App\Wallet;
use Illuminate\Support\Facades\Mail;
use App\Mail\WelcomeMail;
use Illuminate\Foundation\Auth\VerifiesEmails;
use Illuminate\Auth\Events\Verified;
 use Illuminate\Support\Facades\Password; 


class AuthController extends Controller
{
    /**
     * Create a new AuthController instance.
     *
     * @return void
     */
    public function __construct() {
        $this->middleware('jwt', ['except' => ['login', 'register','verifyTxn','forgot_password']]);
    }

    /**
     * Get a JWT via given credentials.
     *
     * @return \Illuminate\Http\JsonResponse
     */
    public function login(Request $request){
        $this->validate($request, [
            'email' => 'required|email',
            'password' => 'required'
        ]);

        $credentials = $request->only('email', 'password');
        try {
            if (!$token = JWTAuth::attempt($credentials)) {
                return response()->json([
                    'status'=>'error',
                    'message'=>'Invalid Credentials'
                ], 401);
            }
        } catch (JWTException $e) {
            return response()->json([
                'status'=>'error',
                'message'=>'Cannot create token'
            ], 500);
        }
        $user=Auth::user();
        
        if($user->email_verified_at !== NULL){

           return $this->createNewToken($token);
        }else{
           return response()->json([
                    'status'=>'error',
                    'message'=>'Please Verify Email'
                ], 401);
        }
    }

    /**
     * Register a User.
     *
     * @return \Illuminate\Http\JsonResponse
     */
    public function register(Request $request) {
        $validator = Validator::make($request->all(), [
             'username' => ['required', 'string', 'max:255','unique:users'],
            'email' => ['required', 'string', 'email', 'max:255', 'unique:users'],
            'password' => ['required', 'string', 'min:8'],
        ]);

        if($validator->fails()){
            return response()->json(
                ['status'=>'error',
              'message'=> $this->getErrorMsg($validator->errors())
                ], 400);
        }


         try{
        $user = User::create(array_merge(
                    $validator->validated(),
                    ['password' => bcrypt($request->password)]
                ));
                
                   $wallet=new Wallet();
                   $balance=
         $wallet->initialize([
            'email'=>$request->input('email')
        ]);


   
   //Mail::to($request->input('email') )->send(new WelcomeMail($request->input('email')   ));
            $user->sendApiEmailVerificationNotification();
          
         
          return response()->json([
            'status'=>'success',
            'message' => 'User successfully registered.Please confirm yourself by clicking on verify user button sent to you on your email',
            'data' => ['user'=>$user,'wallet_balance'=>$balance]
        ], 201);
         
      }   catch (\Exception $e) {
             
               
                return response()->json(
                ['status'=>'error',
              'message'=> 'Internal Server Error' ],400);
              
               }

       
    }
    
      /**
     * Update a User.
     *
     * @return \Illuminate\Http\JsonResponse
     */
    public function updateProfile(Request $request) {
         
       

         try{
          
         $user=Auth::user();   
         $wallet=new Wallet();
         $wallet_balance=$wallet->getBalance($user->email);
         $user->update($request->all());
         $user->save();
         
         if($user)
         return response()->json([
            'status'=>'success',
            'message' => 'User Profile successfully edited',
            'data' => ['user'=>$user,'wallet_balance'=>$wallet_balance]
        ], 201);
        else
         return response()->json([
            'status'=>'failed',
            'message' => 'User Profile not edited'
            
        ], 401);
        
         
         }
         catch (\Exception $e) {
          
         
                return response()->json(
                ['status'=>'error',
              'message'=> 'Internal Server Error' ], 400);
              
               }

        
    }
    
        /**
   * Update a User.
   *
   * @return \Illuminate\Http\JsonResponse
   */
  public function createPin(Request $request) 
  {
      
       $validator = Validator::make($request->all(), [
             'pin' => ['required']
        ]);
       
        if($validator->fails()){
            return response()->json(
                ['status'=>'error',
              'message'=> $this->getErrorMsg($validator->errors())
                ], 400);
        }

       try{
       $user = auth()->user();
       
       $user->update($request->all());

       }
       catch (\Exception $e) {
          
              return response()->json(
              ['status'=>'error',
            'message'=> 'Internal Server Error' ], 400);
            
             }
      return response()->json([
          'status'=>'success',
          'message' => 'User Pin successfully created']);
}



    function changePassword(Request $request) {
      $validator = Validator::make($request->all(), [
            'oldPassword' => ['required', 'string', 'min:8'],
            'password' => ['required', 'string', 'min:8','confirmed']
        ]);

        if($validator->fails()){
            return response()->json([
                'status'=>'error',
                'message'=>$this->getErrorMsg($validator->errors()) ],
                400);
        }
        
       
        
    
         $user = auth()->user();
         $data=$request->all();
          //checking the old password first
         $check  =auth()->attempt([
             'email'=>$user->email,
             'password' => $data['oldPassword']
         ]);
         
             if($check)
             {
 
             $user->password = bcrypt($data['password']);
             $user->save();
             $token = auth()->attempt([
             'email'=>$user->email,
             'password' => $data['password']
         ]);

        

            return response()->json([
                'status'=>'success',
                'message' => 'User successfully reset password',
            'access_token'=>$token
            ],201);
             }else{
                  return response()->json([
                      'status'=>'error',
                      'error' => 'Wrong Old Password'],401);
                 
             }
     
    
       }
       
       
        function changePin(Request $request) {
            
             $validator = Validator::make($request->all(), [
             'pin' => ['required']
        ]);
       
        if($validator->fails()){
            return response()->json(
                ['status'=>'error',
              'message'=> $this->getErrorMsg($validator->errors())
                ], 400);
        }

            $currentPin=auth()->user()->pin;
            
            if($currentPin!=$request->currentPin)
            {
                 return response()->json([
                'status'=>'error',
                'message'=>"Wrong Current Pin" ],
                400);
            }
            
             try{
       $user = auth()->user();
       
       $user->update($request->all());

       }
       catch (\Exception $e) {
          
              return response()->json(
              ['status'=>'error',
            'message'=> 'Internal Server Error' ], 400);
            
             }
      return response()->json([
          'status'=>'success',
          'message' => 'User Pin successfully edited']);
     
    
       }
         function validatePin(Request $request) {
            
             $validator = Validator::make($request->all(), [
             'pin' => ['required']
        ]);
       
        if($validator->fails()){
            return response()->json(
                ['status'=>'error',
              'message'=> $this->getErrorMsg($validator->errors())
                ], 400);
        }

            $pin=auth()->user()->pin;
            
            if($pin!=$request->pin)
            {
                 return response()->json([
                'status'=>'error',
                'message'=>"Wrong  Pin" ],
                400);
            }
            
      
      return response()->json([
          'status'=>'success',
          'message' => 'User Pin successfully validated']);
     
    
       }

    /**
     * Log the user out (Invalidate the token).
     *
     * @return \Illuminate\Http\JsonResponse
     */
    public function logout() {
       
        auth()->logout();

        return response()->json(['message' => 'User successfully signed out']);
    }

    /**
     * Refresh a token.
     *
     * @return \Illuminate\Http\JsonResponse
     */
    public function refresh() {
        return $this->createNewToken(auth()->refresh());
    }

    /**
     * Get the authenticated User.
     *
     * @return \Illuminate\Http\JsonResponse
     */
    public function userProfile() {
         $wallet=new Wallet();
         $balance=$wallet->getBalance(auth()->user()->email);
        
        return response()->json(
            [
            'status'=>'success',
            'user'=> 
                auth()->user(),
                'wallet_balance'=>$balance
            ]
            
           );
    }

    /**
     * Get the token array structure.
     *
     * @param  string $token
     *
     * @return \Illuminate\Http\JsonResponse
     */
    protected function createNewToken($token){
        $wallet=new Wallet();
        $user=auth()->user();
         $balance=$wallet->getBalance($user->email);
        
        return response()->json([
            'status'=>'success',
            'access_token' => $token,
            'token_type' => 'bearer',
             'expires_in' => auth('api')->factory()->getTTL(),
            'user' =>$user,
            'wallet_balance'=>$balance
        ]);
    }
    
    protected function getErrorMsg($errors)
    {
        
        $out="";
        foreach ($errors->all() as $error)
        {
         $out.= $error;
       
        
        }
        return $out;
    }
    
    
        /**
   * Update a User.
   *
   * @return \Illuminate\Http\JsonResponse
   */
  public function changePhoto(Request $request) 
  {
      
       $validator = Validator::make($request->all(), [
         'photo' => 'required|image:jpeg,png,jpg,gif'

        ]);
       
        if($validator->fails()){
            return response()->json(
                ['status'=>'error',
              'message'=> $this->getErrorMsg($validator->errors())
                ], 400);
        }

       try{
       $user=User::find(auth()->user()->id);
       
      
         $image = base64_decode(base64_encode(file_get_contents($request->file('photo'))));
        $safeName = Str::random(20).'.'.'png';
         $path=base_path().'/../../api/assets/img/user/'.$safeName;
        file_put_contents($path,$image);
        $returnPath=url('/assets/img/user/')."/".$safeName;
        

      

       $user->update([
           'photo'=> $returnPath
           ]);
         return response()->json([
          'status'=>'success',
          'message' => 'User Photo successfully changed',
          'path'=>  $returnPath
          
          ]);

       }
       catch (\Exception $e) {
      
          
              return response()->json(
              ['status'=>'error',
            'message'=> 'Internal Server Error' ], 400);
            
       }
}

public function getTvBillers()
{
    $billers=DB::table('biller')
    ->select('billerid','billername')
    ->where('categoryid','=',2)
    ->orderBy('id','DESC')->get();
    
      return response()->json(
              ['status'=>'success',
            'data'=> [
                'balance'=>$billers]],201);
}


public function verifyTxn(Request $request)
    {
        
        $validator = Validator::make($request->all(), [
         'reference' => 'required',
         'amount'=>'required',
         'email'=>'required',
         'service'=>'required'

        ]);
        
       
        if($validator->fails()){
            return response()->json(
                ['status'=>'error',
              'message'=> $this->getErrorMsg($validator->errors())
                ], 400);
        }
        
        $reference=$request->input('reference');
        $amount=$request->input('amount');
        $email=$request->input('email');
        $service=$request->input('service');



        $curl = curl_init();
        

        curl_setopt_array($curl, array(
          CURLOPT_URL => "https://api.flutterwave.com/v3/transactions/".$reference."/verify",
          CURLOPT_RETURNTRANSFER => true,
          CURLOPT_ENCODING => "",
          CURLOPT_MAXREDIRS => 10,
          CURLOPT_TIMEOUT => 0,
          CURLOPT_FOLLOWLOCATION => true,
          CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
          CURLOPT_CUSTOMREQUEST => "GET",
          CURLOPT_HTTPHEADER => array(
            "Content-Type: application/json",
            "Authorization: Bearer FLWSECK_TEST-a5042647614b55b0db0b3ef15c85382d-X"
          ),
        ));
        
        $response = curl_exec($curl);
        
        curl_close($curl);
        echo $response;
    }
    
    
     public function forgot_password() {
        $credentials = request()->validate(['email' => 'required|email']);

        Password::sendResetLink($credentials);

        return response()->json(["msg" => 'Reset password link sent on your email id.']);
    }

}