<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Wallet;
use App\WalletTransactions;
use Auth;

class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index()
    {
        if(Auth::user()->role=="admin")
            return redirect("admin");

        $wallet_txn=new WalletTransactions();
        $wallet_txns=$wallet_txn->getTransactions(Auth::user()->email);
        $wallet_txn_count=$wallet_txn->getTransactionsCnt(Auth::user()->email);
        
        $wallet=new Wallet();
        $wallet_bal=$wallet->getBalance(Auth::user()->email);

        $data['wallet_balance']=$wallet_bal;
        $data['wallet_txns']=$wallet_txns;
        $data['wallet_txn_count']=$wallet_txn_count;

       
        
        return view('home',$data);
    }


    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function admin()
    {
         if(Auth::user()->role=="user")
            return redirect("home");
        $wallet_txn=new WalletTransactions();
        $wallet_txns=$wallet_txn->getTransactions(Auth::user()->email);
        $wallet_txn_count=$wallet_txn->getTransactionsCnt(Auth::user()->email);
        
        $wallet=new Wallet();
        $wallet_bal=$wallet->getBalance(Auth::user()->email);

        $data['wallet_balance']=$wallet_bal;
        $data['wallet_txns']=$wallet_txns;
        $data['wallet_txn_count']=$wallet_txn_count;

        return view('adminhome',$data);
    }
}
