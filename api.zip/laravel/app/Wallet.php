<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use App\WalletTransactions;

class Wallet extends Model
{
    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'email','balance'
    ];




    public function initialize($data)
    {
         Wallet::create([
         	'email'=>$data['email'],
         	'balance'=>0
         ]);
        WalletTransactions::create([
        	'email'=>$data['email'],
        	'txn_type'=>'CREDIT',
        	'amount'=>0
        ]);
        
        return $this->getBalance($data['email']);

    }

    public function credit($data)
    {
        Wallet::where('email',$data['email'])->update(['balance'=>$data['amount']+$this->getBalance($data['email'])]);
        WalletTransactions::create([
            'email'=>$data['email'],
            'txn_type'=>'CREDIT',
            'amount'=>$data['amount']
        ]);

    }
     public function debit($data)
    {
        Wallet::where('email',$data['email'])->update(['balance'=>$this->getBalance($data['email'])-$data['amount']]);
        WalletTransactions::create([
            'email'=>$data['email'],
            'txn_type'=>'DEBIT',
            'amount'=>$data['amount']
        ]);

    }

    public function getBalance($email)
    {
    	$wallet=Wallet::where('email',$email)->first();
    
    	return $wallet['balance'];
    }

}
