@extends('layouts.app')

@section('content')
               

                 <form method="POST" action="{{ route('addfunds') }}">
                        @csrf
                    <h1>Add Funds</h1>
                                        <div class="text-muted text-center mb-4">
                                        	@if(isset($message))
                                        	<div class="alert alert-danger alert-dismissable fade show p-3">
  <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
  <p>{{$message}}</p>
</div>
@endif
                                            </div>
                    <div class="mb-3 row">
                        <label class="form-label">{{ __('Amount') }}</label>
                         <div class="col-sm-5">
<input id="amount" type="number" class="form-control @error('amount') is-invalid @enderror" name="amount" value="{{ old('amount') }}" required autocomplete="amount" autofocus>
</div>

                                @error('amount')
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                                @enderror                   </div>
                   
                   <div class="mb-3 row">
    <div class="col-sm-5 ">
                    <button type="submit" class="btn btn-primary btn-lg d-block w-100 fw-500 mb-3" name="Submit"> {{ __('Pay with Paystack') }}</button>
                   
                </div>
        </div>
    </form>
          
			</div>
@endsection