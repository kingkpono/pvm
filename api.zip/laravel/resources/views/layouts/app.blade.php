<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8" />
      <!-- CSRF Token -->
    <meta name="csrf-token" content="{{ csrf_token() }}">

    <title>{{ config('app.name', 'Laravel') }}</title>
    <!-- Scripts -->
    <script src="{{ asset('js/app.js') }}" defer></script>

    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet">

    <!-- Styles -->
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <meta name="description" content="" />
    <meta name="author" content="" />
    
    <!-- ================== BEGIN core-css ================== -->
    <link href="{{ asset('assets/css/vendor.min.css') }}" rel="stylesheet" />
    <link href="{{ asset('assets/css/app.min.css') }}" rel="stylesheet" />
    <!-- ================== END core-css ================== -->
    
</head>
<body class="app-footer-fixed">
    <!-- BEGIN #app -->
    <div id="app" class="app">
        <!-- BEGIN #header -->
        <div id="header" class="app-header">
            <!-- BEGIN mobile-toggler -->
            <div class="mobile-toggler">
                <button type="button" class="menu-toggler" data-toggle="sidebar-mobile">
                    <span class="bar"></span>
                    <span class="bar"></span>
                </button>
            </div>
            <!-- END mobile-toggler -->
            
            <!-- BEGIN brand -->
            <div class="brand">
                <div class="desktop-toggler">
                    <button type="button" class="menu-toggler" data-toggle="sidebar-minify">
                        <span class="bar"></span>
                        <span class="bar"></span>
                    </button>
                </div>
                
                <a href="/" class="brand-logo">
                    <H2>Wrallo</H2>
                </a>
            </div>
            <!-- END brand -->
            
            <!-- BEGIN menu -->
                <div class="menu">
                <form class="menu-search" method="POST" name="header_search_form">
                    <div class="menu-search-icon"><i class="fa fa-search"></i></div>
                    <div class="menu-search-input">
                        <input type="text" class="form-control" placeholder="Search menu..." />
                    </div>
                </form>
                
                            <div class="menu-item dropdown">
                    <a href="#" data-bs-toggle="dropdown" data-bs-display="static" class="menu-link">
                        <div class="menu-img online">
                            <img src="assets/img/user/avatar.png" alt="" class="mw-100 mh-100 rounded-circle" />
                        </div>
                        <div class="menu-text">                                    {{ Auth::user()->firstname }}
</div>
                    </a>
                    <div class="dropdown-menu dropdown-menu-end me-lg-3">
                            <a class="dropdown-item d-flex align-items-center"href="{{ route('logout') }}"
                                       onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                                        {{ __('Logout') }}<i class="fa fa-toggle-off fa-fw ms-auto text-gray-400 fs-16px"></i></a>
                                        <form id="logout-form" action="{{ route('logout') }}" method="POST" class="d-none">
                                        @csrf
                                    </form>
                    </div>
                </div>
            </div>
            <!-- END menu -->
        </div>
        <!-- END #header -->
        
        <!-- BEGIN #sidebar -->
            <div id="sidebar" class="app-sidebar">
            <!-- BEGIN scrollbar -->
            <div class="app-sidebar-content" data-scrollbar="true" data-height="100%">
                <!-- BEGIN menu -->
                <div class="menu">
                    <div class="menu-header">Navigation</div>
                    <div class="menu-item active">
                        <a href="/" class="menu-link">
                            <span class="menu-icon"><i class="fa fa-laptop"></i></span>
                            <span class="menu-text">Dashboard</span>
                        </a>
                    </div>
                    
                    <div class="menu-item has-sub">
                        <a href="#" class="menu-link">
                            <span class="menu-icon">
                                <i class="fa fa-phone"></i>
                            </span>
                            <span class="menu-text">Airtime</span>
                            <span class="menu-caret"><b class="caret"></b></span>
                        </a>
                        <div class="menu-submenu">
                                <div class="menu-item">
                                <a href="/airtel" class="menu-link">
                                    <span class="menu-text">AIRTEL</span>
                                </a>
                            </div>
                            <div class="menu-item">
                                <a href="/mtn" class="menu-link">    <span class="menu-text">MTN</span>
                                </a>
                            </div>
                            <div class="menu-item">
                                <a href="/ninemobile" class="menu-link">
                                    <span class="menu-text">9Mobile</span>
                                </a>
                            </div>
                            <div class="menu-item">
                                <a href="/glo" class="menu-link">
                                    <span class="menu-text">Glo</span>
                                </a>
                            </div>
                        </div>
                    </div>
                    <div class="menu-item has-sub">
                        <a href="#" class="menu-link">
                            <span class="menu-icon">
                                <i class="fa fa-receipt"></i>
                                
                            </span>
                            <span class="menu-text">Bill Payments</span>
                            <span class="menu-v"><b class="caret"></b></span>
                        </a>
                        <div class="menu-submenu">
                            <div class="menu-item">
                                <a href="/startimes" class="menu-link">
                                    <span class="menu-text">STARTIMES</span>
                                </a>
                            </div>
                            <div class="menu-item">
                                <a href="/gotv" class="menu-link">
                                    <span class="menu-text">GOTV</span>
                                </a>
                            </div>
                            <div class="menu-item">
                                <a href="/dstv" class="menu-link">
                                    <span class="menu-text">DSTV</span>
                                </a>
                            </div>
                                <div class="menu-item">
                                <a href="/phcn" class="menu-link">
                                    <span class="menu-text">PHCN</span>
                                </a>
                            </div>
                        </div>
                    </div>

                    <div class="menu-item has-sub">
                        <a href="#" class="menu-link">
                            <span class="menu-icon">
                                <i class="fa fa-wallet"></i>
                                
                            </span>
                            <span class="menu-text">My Wallet(₦{{$wallet_balance}})</span>
                            <span class="menu-v"><b class="caret"></b></span>
                        </a>
                        <div class="menu-submenu">
                            <div class="menu-item">
                                <a href="{{ route('addfunds') }}" class="menu-link">
                                    <span class="menu-text">ADD FUNDS</span>
                                </a>
                            </div>
                        
                        </div>
                    </div>
                    <div class="menu-divider"></div>
                    
                </div>
                <!-- END menu -->
            </div>
            <!-- END scrollbar -->
            
            <!-- BEGIN mobile-sidebar-backdrop -->
            <button class="app-sidebar-mobile-backdrop" data-dismiss="sidebar-mobile"></button>
            <!-- END mobile-sidebar-backdrop -->
        </div>
        <!-- END #sidebar -->
        
        <!-- BEGIN #content -->
        <div id="content" class="app-content">
             @yield('content')
            
        <!-- END #content -->
        
        <!-- BEGIN btn-scroll-top -->
        <a href="#" data-click="scroll-top" class="btn-scroll-top fade"><i class="fa fa-arrow-up"></i></a>
        <!-- END btn-scroll-top -->
        
         <div id="footer" class="app-footer" style="float: left !important">
    © 2021 Wrallo. All Rights Reserved.
  </div>
    </div>
    <!-- END #app -->
   
    
<!-- END #app -->
    
    <!-- ================== BEGIN core-js ================== -->
    <script src="{{ asset('assets/js/vendor.min.js') }}"></script>
    <script src="{{ asset('assets/js/app.min.js') }}"></script>
    <!-- ================== END core-js ================== -->

</body>

</html>
