@extends('layouts.auth')

@section('content')
   <!-- BEGIN login -->
        <div class="login">
            <!-- BEGIN login-content -->
            <div class="login-content">
                 <form method="POST" action="{{ route('login') }}">
                        @csrf

                         <a href="/" class="brand-logo"><h1 class="text-center">Wrallo</h1></a><br/>
                    <h3 class="text-center">Sign In</h3>
                                        <div class="text-muted text-center mb-4">
                                            </div>
                    <div class="mb-3">
                        <label class="form-label">{{ __('E-Mail Address') }}</label>
<input id="email" type="email" class="form-control @error('email') is-invalid @enderror" name="email" value="{{ old('email') }}" required autocomplete="email" autofocus>

                                @error('email')
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                                @enderror                   </div>
                    <div class="mb-3">
                        <div class="d-flex">
                            <label class="form-label">{{ __('Password') }}</label>
                             @if (Route::has('password.request'))
                            <a href="{{ route('password.request') }}" class="ms-auto text-muted" > {{ __('Forgot Your Password?') }}</a>
                             @endif

                        </div>
                        <input id="password" type="password" class="form-control @error('password') is-invalid @enderror" name="password" required autocomplete="current-password">

                                @error('password')
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                                @enderror
                    </div>
                    <div class="mb-3">
                        <div class="form-check">
                            <input type="checkbox" name="remember" {{ old('remember') ? 'checked' : '' }}>
                            <label class="form-check-label fw-500" for="customCheck1">{{ __('Remember me') }}</label>
                        </div>
                    </div>
                    <button type="submit" class="btn btn-primary btn-lg d-block w-100 fw-500 mb-3" name="Submit"> {{ __('Login') }}</button>
                    <div class="text-center text-muted">
                        Don't have an account yet? <a href="{{ route('register') }}">Sign up</a>.
                    </div>
                </form>
            </div>
            <!-- END login-content -->
        </div>
        <!-- END login -->
        @endsection
