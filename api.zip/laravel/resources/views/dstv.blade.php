 @extends('layouts.app')

@section('content')
               
            <div class="login-content">
 <form method="post" action="/dstv" >
 <div>
  <img  src="https://payviame.com/wp-content/uploads/2020/12/dstv.jpg"/>
  <br/>
                       <h4>Dstv Subscription</h4>

      </div>
      
    <div class="mb-3 row">
     <label for="mobile_number" >Bouqet</label>
                <div class="col-sm-5">

       <select id="paymentCode" name="paymentCode"  class="form-control" onchange="val()" >
       <option value="">Select Bouqet</option>
   
    </select>
      
    </div>
     </div>
    
     <div class="mb-3 row">   
     <label for="iuc" class="control-label">IUC #</label><i class="bar"></i>
     <div class="col-sm-5">
    <input type="text"  name="iuc" class="form-control"/>
    </div>
    </div>
     <div class="mb-3 row">    
     <label for="mobile_number" class="control-label">Phone #</label>
      <div class="col-sm-5">
    <input type="text"  name="mobile_number" class="form-control" required/>
    </div>
    </div>
    
   
      <div class="mb-3 row">       
     <label for="amount" class="control-label">Amount</label>

       <div class="col-sm-5">  
    <input   type="text" class="form-control"  value=" " name="amount" id="amount" />
    </div>
    </div>
     <div class="mb-3 row">
         <div class="col-sm-5">

<button  name="paymentItems" class="btn-primary" value="Next" type="submit"  >Continue</button>

      </div>
      </div>

</form>
      </div>
@endsection


