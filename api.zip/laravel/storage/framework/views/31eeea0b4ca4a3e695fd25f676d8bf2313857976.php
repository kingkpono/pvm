<?php echo e($slot); ?>

<?php /**PATH /home/ictconne/public_html/api/laravel/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>