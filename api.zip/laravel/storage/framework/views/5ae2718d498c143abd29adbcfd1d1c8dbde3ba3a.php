

<?php $__env->startSection('content'); ?>
               
            <div class="login-content">

                 <form method="POST" action="<?php echo e(route('addfunds')); ?>">
                        <?php echo csrf_field(); ?>
                    <h1 class="text-center">Add Funds</h1>
                                        <div class="text-muted text-center mb-4">
                                        	<?php if(isset($message)): ?>
                                        	<div class="alert alert-danger alert-dismissable fade show p-3">
  <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
  <p><?php echo e($message); ?></p>
</div>
<?php endif; ?>
                                            </div>
                    <div class="mb-3">
                        <label class="form-label"><?php echo e(__('Amount')); ?></label>
<input id="amount" type="number" class="form-control <?php $__errorArgs = ['amount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="amount" value="<?php echo e(old('amount')); ?>" required autocomplete="amount" autofocus>

                                <?php $__errorArgs = ['amount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>                   </div>
                   
                   
                    <button type="submit" class="btn btn-primary btn-lg d-block w-100 fw-500 mb-3" name="Submit"> <?php echo e(__('Pay with Paystack')); ?></button>
                   
                </form>
          
			</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\hp\wrallo\resources\views\addfunds.blade.php ENDPATH**/ ?>