 

<?php $__env->startSection('content'); ?>
               
            <div class="login-content">

              <form method="post"  action="<?php echo e(route('airtel')); ?>">
        <div>
                    <img  src="https://payviame.com/wp-content/uploads/2020/12/airtel.jpg"/><br/>
                       <h4>Airtel Airtime</h4>

            </div>

     <div class="mb-3 row">
          <label for="mobile_number" >Mobile Number:</label>
      <div class="col-sm-5">
     <input type="text" required  class="form-control"  name="mobile_number" />
     </div>
   </div>

      <div class="mb-3 row">
          <label for="mobile_number" >Amount:</label>
                <div class="col-sm-5">

     <input type="text" class="form-control"  name="amount" />
     </div>
   </div>
      <div class="mb-3 row">
         <div class="col-sm-5">
<input  name="paymentItems" value="Continue" type="submit" class="btn btn-primary" />
</div>
</div>

</form>
      </div>
<?php $__env->stopSection(); ?>


 
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\hp\wrallo\resources\views/airtel.blade.php ENDPATH**/ ?>