<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8" />
    <title><?php echo e(config('app.name', 'Laravel')); ?></title>
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <meta name="description" content="" />
    <meta name="author" content="" />
    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <!-- Scripts -->
    <script src="<?php echo e(asset('js/app.js')); ?>" defer></script>

    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet">

    <!-- Styles -->
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
    <!-- ================== BEGIN core-css ================== -->
    <link href="<?php echo e(asset('assets/css/vendor.min.css')); ?>" rel="stylesheet" />
    <link href="<?php echo e(asset('assets/css/app.min.css')); ?>" rel="stylesheet" />
    <!-- ================== END core-css ================== -->
    
</head>

<body>

    <!-- BEGIN #app -->
    <div id="app" class="app app-full-height app-without-header">
                 <?php echo $__env->yieldContent('content'); ?>

        
        <!-- BEGIN btn-scroll-top -->
        <a href="#" data-click="scroll-top" class="btn-scroll-top fade"><i class="fa fa-arrow-up"></i></a>
        <!-- END btn-scroll-top -->
        <footer  class="footer" style="float:right;"
         ><span class="text-center">2021 Wrallo Limited •<a id="termsLink" dtarget="_blank" href="https://wrallo.us/terms-of-use" style="font-size: 1.25em;"> T and Cs</a><span style="margin-left: 10px; font-size: 1.25em;"><a id="faqsLink" target="_blank" href="https://www.wrallo.us/faq">HELP</a></span></span></footer>
    </div>
    <!-- END #app -->
    
    <!-- ================== BEGIN core-js ================== -->
    <script src="<?php echo e(asset('assets/js/vendor.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/app.min.js')); ?>"></script>
    <!-- ================== END core-js ================== -->

</body>
<?php /**PATH C:\Users\hp\wrallo\resources\views\layouts\auth.blade.php ENDPATH**/ ?>