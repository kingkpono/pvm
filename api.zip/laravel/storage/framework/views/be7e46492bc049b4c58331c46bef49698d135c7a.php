<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8" />
      <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'Laravel')); ?></title>
    <!-- Scripts -->
    <script src="<?php echo e(asset('js/app.js')); ?>" defer></script>

    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet">

    <!-- Styles -->
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <meta name="description" content="" />
    <meta name="author" content="" />
    
    <!-- ================== BEGIN core-css ================== -->
    <link href="<?php echo e(asset('assets/css/vendor.min.css')); ?>" rel="stylesheet" />
    <link href="<?php echo e(asset('assets/css/app.min.css')); ?>" rel="stylesheet" />
    <!-- ================== END core-css ================== -->
    
</head>
<body>
    <!-- BEGIN #app -->
    <div id="app" class="app">
        <!-- BEGIN #header -->
        <div id="header" class="app-header">
            <!-- BEGIN mobile-toggler -->
            <div class="mobile-toggler">
                <button type="button" class="menu-toggler" data-toggle="sidebar-mobile">
                    <span class="bar"></span>
                    <span class="bar"></span>
                </button>
            </div>
            <!-- END mobile-toggler -->
            
            <!-- BEGIN brand -->
            <div class="brand">
                <div class="desktop-toggler">
                    <button type="button" class="menu-toggler" data-toggle="sidebar-minify">
                        <span class="bar"></span>
                        <span class="bar"></span>
                    </button>
                </div>
                
                <a href="#" class="brand-logo">
                    <H2>Wrallo</H2>
                </a>
            </div>
            <!-- END brand -->
            
            <!-- BEGIN menu -->
                <div class="menu">
                <form class="menu-search" method="POST" name="header_search_form">
                    <div class="menu-search-icon"><i class="fa fa-search"></i></div>
                    <div class="menu-search-input">
                        <input type="text" class="form-control" placeholder="Search menu..." />
                    </div>
                </form>
                <div class="menu-item dropdown">
                    <a href="#" data-bs-toggle="dropdown" data-bs-display="static" class="menu-link">
                        <div class="menu-icon" 
                         ><i class="fa fa-wallet" style="color #3C4E71;"></i> 
                            <span style='font:14px system-ui,-apple-system,"Segoe UI",Roboto,"Helvetica Neue",Arial,"Noto Sans","Liberation Sans",sans-serif,"Apple Color Emoji","Segoe UI Emoji","Segoe UI Symbol","Noto Color Emoji";color #3C4E71;'>₦<?php echo e($wallet_balance); ?></span></div>
                        
                    </a>
                    
                </div>
                            <div class="menu-item dropdown">
                    <a href="#" data-bs-toggle="dropdown" data-bs-display="static" class="menu-link">
                        <div class="menu-img online">
                            <img src="assets/img/user/avatar.png" alt="" class="mw-100 mh-100 rounded-circle" />
                        </div>
                        <div class="menu-text">                                    <?php echo e(Auth::user()->firstname); ?>

</div>
                    </a>
                    <div class="dropdown-menu dropdown-menu-end me-lg-3">
                            <a class="dropdown-item d-flex align-items-center"href="<?php echo e(route('logout')); ?>"
                                       onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                                        <?php echo e(__('Logout')); ?><i class="fa fa-toggle-off fa-fw ms-auto text-gray-400 fs-16px"></i></a>
                                        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                                        <?php echo csrf_field(); ?>
                                    </form>
                    </div>
                </div>
            </div>
            <!-- END menu -->
        </div>
        <!-- END #header -->
        
        <!-- BEGIN #sidebar -->
            <div id="sidebar" class="app-sidebar">
            <!-- BEGIN scrollbar -->
            <div class="app-sidebar-content" data-scrollbar="true" data-height="100%">
                <!-- BEGIN menu -->
                <div class="menu">
                    <div class="menu-header">Navigation</div>
                    <div class="menu-item active">
                        <a href="index.php" class="menu-link">
                            <span class="menu-icon"><i class="fa fa-laptop"></i></span>
                            <span class="menu-text">Dashboard</span>
                        </a>
                    </div>
                    
                    <div class="menu-item has-sub">
                        <a href="#" class="menu-link">
                            <span class="menu-icon">
                                <i class="fa fa-phone"></i>
                            </span>
                            <span class="menu-text">Airtime</span>
                            <span class="menu-caret"><b class="caret"></b></span>
                        </a>
                        <div class="menu-submenu">
                                <div class="menu-item">
                                <a href="airtel.php" class="menu-link">
                                    <span class="menu-text">AIRTEL</span>
                                </a>
                            </div>
                            <div class="menu-item">
                                <a href="mtn.php" class="menu-link">    <span class="menu-text">MTN</span>
                                </a>
                            </div>
                            <div class="menu-item">
                                <a href="ninemobile.php" class="menu-link">
                                    <span class="menu-text">9Mobile</span>
                                </a>
                            </div>
                            <div class="menu-item">
                                <a href="glo.php" class="menu-link">
                                    <span class="menu-text">Glo</span>
                                </a>
                            </div>
                        </div>
                    </div>
                    <div class="menu-item has-sub">
                        <a href="#" class="menu-link">
                            <span class="menu-icon">
                                <i class="fa fa-receipt"></i>
                                
                            </span>
                            <span class="menu-text">Bill Payments</span>
                            <span class="menu-v"><b class="caret"></b></span>
                        </a>
                        <div class="menu-submenu">
                            <div class="menu-item">
                                <a href="startimes.php" class="menu-link">
                                    <span class="menu-text">STARTIMES</span>
                                </a>
                            </div>
                            <div class="menu-item">
                                <a href="gotv.php" class="menu-link">
                                    <span class="menu-text">GOTV</span>
                                </a>
                            </div>
                            <div class="menu-item">
                                <a href="dstv.php" class="menu-link">
                                    <span class="menu-text">DSTV</span>
                                </a>
                            </div>
                                <div class="menu-item">
                                <a href="phcn.php" class="menu-link">
                                    <span class="menu-text">PHCN</span>
                                </a>
                            </div>
                        </div>
                    </div>

                    <div class="menu-item has-sub">
                        <a href="#" class="menu-link">
                            <span class="menu-icon">
                                <i class="fa fa-wallet"></i>
                                
                            </span>
                            <span class="menu-text">My Wallet</span>
                            <span class="menu-v"><b class="caret"></b></span>
                        </a>
                        <div class="menu-submenu">
                            <div class="menu-item">
                                <a href="<?php echo e(route('addfunds')); ?>" class="menu-link">
                                    <span class="menu-text">ADD FUNDS</span>
                                </a>
                            </div>
                        
                        </div>
                    </div>
                    <div class="menu-divider"></div>
                    
                </div>
                <!-- END menu -->
            </div>
            <!-- END scrollbar -->
            
            <!-- BEGIN mobile-sidebar-backdrop -->
            <button class="app-sidebar-mobile-backdrop" data-dismiss="sidebar-mobile"></button>
            <!-- END mobile-sidebar-backdrop -->
        </div>
        <!-- END #sidebar -->
        
        <!-- BEGIN #content -->
        <div id="content" class="app-content">
             <?php echo $__env->yieldContent('content'); ?>
            
        <!-- END #content -->
        
        <!-- BEGIN btn-scroll-top -->
        <a href="#" data-click="scroll-top" class="btn-scroll-top fade"><i class="fa fa-arrow-up"></i></a>
        <!-- END btn-scroll-top -->
         <footer  class="footer" style="float:right;"
         ><span class="text-center">2021 Wrallo Limited •<a id="termsLink" dtarget="_blank" href="https://wrallo.us/terms-of-use" style="font-size: 1.25em;"> T and Cs</a><span style="margin-left: 10px; font-size: 1.25em;"><a id="faqsLink" target="_blank" href="https://www.wrallo.us/faq">HELP</a></span></span></footer>
    </div>
    <!-- END #app -->
    
<!-- END #app -->
    
    <!-- ================== BEGIN core-js ================== -->
    <script src="<?php echo e(asset('assets/js/vendor.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/app.min.js')); ?>"></script>
    <!-- ================== END core-js ================== -->

</body>
<?php /**PATH C:\Users\hp\wrallo\resources\views\layouts\app.blade.php ENDPATH**/ ?>