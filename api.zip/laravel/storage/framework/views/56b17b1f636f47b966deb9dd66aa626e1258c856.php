 

<?php $__env->startSection('content'); ?>
               
            <div class="login-content">
 <form method="post" action="/phcn">
        <div>
                   <center> <img  src="https://payviame.com/wp-content/uploads/2020/12/phcn.jpg"/><br/>
                       <h4>Electricity Bill</h4></center>

            </div>


    
     <div class="mb-3 row">   
          <label for="mobile_number" >Electricity Company</label>
          <div class="col-sm-5">
    <select name="billerId" class="form-control">'.$options.'</select>
    </div>
  </div>
   <div class="mb-3 row"> 
          <label for="meter_number" >Meter Number:</label>
     <div class="col-sm-5">     
     <input type="text" required  class="form-control"  name="meter_number" required/>
 
     </div>
   </div>
     
     
     <div class="mb-3 row"> 
          <label for="amount" >Amount:</label>
       <div class="col-sm-5">     
     <input type="text" class="form-control"  name="amount" required/>
     </div> 
   </div>
     <div class="mb-3 row">
          <label for="mobile_number" >Phone:</label>
      <div class="col-sm-5">
     <input type="text" class="form-control"  name="mobile_number" required/>
     </div>
   </div>
     
   <div class="mb-3 row">
    <div class="col-sm-5">
<input  name="paymentItems" value="Next" type="submit" class="btn btn-primary" />
</div>
</div>
</form>

      </div>
<?php $__env->stopSection(); ?>


 
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\hp\wrallo\resources\views/phcn.blade.php ENDPATH**/ ?>