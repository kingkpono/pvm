<DOCTYPE html>
   <html lang="en-US">
     <head>
     <meta charset="utf-8">
     </head>
     <body>
     <h2>                                                                                  Hi <?php echo e($data['email']); ?>, welcome to PayViaMe.
</h3>

</body>
</html><?php /**PATH /home/ictconne/public_html/api/laravel/resources/views/email/welcome.blade.php ENDPATH**/ ?>