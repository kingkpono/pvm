<?php $__env->startSection('content'); ?>
<h1 class="page-header mb-3">
                Hi, <?php echo e(Auth::user()->firstname); ?>. <small>here's what's happening with your Wrallo account today.</small>
            </h1>
            
            
        
                 
                 <?php
                 /*if($_GET['wallet_add_funds']=="success")
                 {
                        ?><div class="alert alert-success alert-dismissable fade show p-3">
  <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
  <p>A Credit transcation has occured on your wallet</p>
                 </div>
                 <?php
                 }
                 
                  if($_GET['wallet_add_funds']=="failure" &&
                  isset($_GET['message']))
                 {
                     $failure=$_GET['message'];
                        ?><div class="alert alert-danger alert-dismissable fade show p-3">
  <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
  <p>,?php  echo  $failure;?></p>
                 </div>
                 <?php
                 }
                 */
                 ?>
            
            <!-- BEGIN row -->
            <div class="row">
                <!-- BEGIN col-6 -->
                <div class="col-xl-6">
                    <!-- BEGIN card -->
                    <div class="card text-white-transparent-7 mb-3 overflow-hidden">
                        <!-- BEGIN card-img-overlay -->
                        <div class="card-img-overlay d-block d-lg-none bg-blue rounded"></div>
                        <!-- END card-img-overlay -->
                        
                        <!-- BEGIN card-img-overlay -->
                        <div class="card-img-overlay d-none d-md-block bg-blue rounded" style="background-image: url(assets/img/bg/wave-bg.png); background-position: right bottom; background-repeat: no-repeat; background-size: 100%;"></div>
                        <!-- END card-img-overlay -->
                        
                        <!-- BEGIN card-img-overlay -->
                        <div class="card-img-overlay d-none d-md-block bottom-0 top-auto">
                            <div class="row">
                                <div class="col-md-8 col-xl-6"></div>
                                <div class="col-md-4 col-xl-6 mb-n2">
                                    <img src="assets/img/page/dashboard.svg" alt="" class="d-block ms-n3 mb-5" style="max-height: 310px" />
                                </div>
                            </div>
                        </div>
                        <!-- END card-img-overlay -->
                        
                        <!-- BEGIN card-body -->
                        <div class="card-body position-relative">
                            <!-- BEGIN row -->
                            <div class="row">
                                <!-- BEGIN col-8 -->
                                <div class="col-md-8">
                                    <!-- stat-top -->
                                    <div class="d-flex">
                                        <div class="me-auto">
                                            <h5 class="text-white-transparent-8 mb-3">Weekly Earning</h5>
                                            <h3 class="text-white mt-n1 mb-1">₦2,999.80</h3>
                                            <p class="mb-1 text-white-transparent-6 text-truncate">
                                                <i class="fa fa-caret-up"></i> <b>32%</b> increase compare to last week
                                            </p>
                                        </div>
                                    </div>
                                    
                                    <hr class="hr-transparent bg-white-transparent-2 mt-3 mb-3" />
                                    
                                    <!-- stat-bottom -->
                                    <div class="row">
                                        <div class="col-6 col-lg-5">
                                            <div class="mt-1">
                                                <i class="fa fa-fw fa-shopping-bag fs-28px text-black-transparent-5"></i>
                                            </div>
                                            <div class="mt-1">
                                                <div>Store Sales</div>
                                                <div class="font-weight-600 text-white">₦1,629.80</div>
                                            </div>
                                        </div>
                                        <div class="col-6 col-lg-5">
                                            <div class="mt-1">
                                                <i class="fa fa-fw fa-retweet fs-28px text-black-transparent-5"></i>
                                            </div>
                                            <div class="mt-1">
                                                <div>Referral Sales</div>
                                                <div class="font-weight-600 text-white">₦700.00</div>
                                            </div>
                                        </div>
                                    </div>
                                    
                                    <hr class="hr-transparent bg-white-transparent-2 mt-3 mb-3" />
                                    
                                    <div class="mt-3 mb-2">
                                        <a href="/add_funds.php" class="btn btn-yellow btn-rounded btn-sm ps-5 pe-5 pt-2 pb-2 fs-14px font-weight-600"><i class="fa fa-wallet me-2 ms-n2"></i> Fund Wallet</a>
                                    </div>
                                    <p class="fs-12px">
                                        It usually takes 3-5 business days for transferring the earning to your bank account.
                                    </p>
                                </div>
                                <!-- END col-8 -->
                                
                                <!-- BEGIN col-4 -->
                                <div class="col-md-4 d-none d-md-block" style="min-height: 380px;"></div>
                                <!-- END col-4 -->
                            </div>
                            <!-- END row -->
                        </div>
                        <!-- END card-body -->
                    </div>
                    <!-- END card -->
                </div>
                <!-- END col-6 -->
                
                <!-- BEGIN col-6 -->
                <div class="col-xl-6">
                    <!-- BEGIN row -->
                    <div class="row">
                        <!-- BEGIN col-6 -->
                        <div class="col-sm-6">
                            <!-- BEGIN card -->
                            <div class="card mb-3 overflow-hidden fs-13px border-0 bg-gradient-custom-orange" style="min-height: 202px;">
                                <!-- BEGIN card-img-overlay -->
                                <div class="card-img-overlay mb-n4 me-n4 d-flex" style="bottom: 0; top: auto;">
                                    <img src="assets/img/icon/order.svg" alt="" class="ms-auto d-block mb-n3" style="max-height: 105px" />
                                </div>
                                <!-- END card-img-overlay -->
                                
                                <!-- BEGIN card-body -->
                                <div class="card-body position-relative">
                                    <h5 class="text-white-transparent-8 mb-3 fs-16px">Wallet Orders</h5>
                                    <h3 class="text-white mt-n1">
                                    <?php echo e($wallet_txn_count); ?>

                                    </h3>
                                    <div class="progress bg-black-transparent-5 mb-2" style="height: 6px">
                                        <div class="progrss-bar progress-bar-striped bg-white" style="width: 
                                        <?php echo e($wallet_txn_count); ?>%"></div>
                                    </div>
                                    <div class="text-white-transparent-8 mb-4"><i class="fa fa-caret-up"></i> <?php// echo $wallet_txn_cnt;
                                    ?>% increase <br />compare to last week</div>
                                    <div><a href="#" class="text-white d-flex align-items-center text-decoration-none">View report <i class="fa fa-chevron-right ms-2 text-white-transparent-5"></i></a></div>
                                </div>
                                <!-- BEGIN card-body -->
                            </div>
                            <!-- END card -->
                            
                            <!-- BEGIN card -->
                            <div class="card mb-3 overflow-hidden fs-13px border-0 bg-gradient-custom-teal" style="min-height: 202px;">
                                <!-- BEGIN card-img-overlay -->
                                <div class="card-img-overlay mb-n4 me-n4 d-flex" style="bottom: 0; top: auto;">
                                    <img src="assets/img/icon/visitor.svg" alt="" class="ms-auto d-block mb-n3" style="max-height: 105px" />
                                </div>
                                <!-- END card-img-overlay -->
                                
                                <!-- BEGIN card-body -->
                                <div class="card-body position-relative">
                                    <h5 class="text-white-transparent-8 mb-3 fs-16px">Billing Payments</h5>
                                    <h3 class="text-white mt-n1">0</h3>
                                    <div class="progress bg-black-transparent-5 mb-2" style="height: 6px">
                                        <div class="progrss-bar progress-bar-striped bg-white" style="width: 0%"></div>
                                    </div>
                                    <div class="text-white-transparent-8 mb-4"><i class="fa fa-caret-up"></i> 0% increase <br />compare to last week</div>
                                    <div><a href="#" class="text-white d-flex align-items-center text-decoration-none">View report <i class="fa fa-chevron-right ms-2 text-white-transparent-5"></i></a></div>
                                </div>
                                <!-- END card-body -->
                            </div>
                            <!-- END card -->
                        </div>
                        <!-- END col-6 -->
                        
                        <!-- BEGIN col-6 -->
                        <div class="col-sm-6">
                            <!-- BEGIN card -->
                            <div class="card mb-3 overflow-hidden fs-13px border-0 bg-gradient-custom-pink" style="min-height: 202px;">
                                <!-- BEGIN card-img-overlay -->
                                <div class="card-img-overlay mb-n4 me-n4 d-flex" style="bottom: 0; top: auto;">
                                    <img src="assets/img/icon/email.svg" alt="" class="ms-auto d-block mb-n3" style="max-height: 105px" />
                                </div>
                                <!-- END card-img-overlay -->
                                
                                <!-- BEGIN card-body -->
                                <div class="card-body position-relative">
                                    <h5 class="text-white-transparent-8 mb-3 fs-16px">Airtime Recharge</h5>
                                    <h3 class="text-white mt-n1">0</h3>
                                    <div class="progress bg-black-transparent-5 mb-2" style="height: 6px">
                                        <div class="progrss-bar progress-bar-striped bg-white" style="width: 0%"></div>
                                    </div>
                                    <div class="text-white-transparent-8 mb-4"><i class="fa fa-caret-down"></i> 0% decrease <br />compare to last week</div>
                                    <div><a href="#" class="text-white d-flex align-items-center text-decoration-none">View report <i class="fa fa-chevron-right ms-2 text-white-transparent-5"></i></a></div>
                                </div>
                                <!-- END card-body -->
                            </div>
                            <!-- END card -->
                            
                            <!-- BEGIN card -->
                            <div class="card mb-3 overflow-hidden fs-13px border-0 bg-gradient-custom-indigo" style="min-height: 202px;">
                                <!-- BEGIN card-img-overlay -->
                                <div class="card-img-overlay mb-n4 me-n4 d-flex" style="bottom: 0; top: auto;">
                                    <img src="assets/img/icon/browser.svg" alt="" class="ms-auto d-block mb-n3" style="max-height: 105px" />
                                </div>
                                <!-- end card-img-overlay -->
                                
                                <!-- BEGIN card-body -->
                                <div class="card-body position-relative">
                                    <h5 class="text-white-transparent-8 mb-3 fs-16px">Page Views</h5>
                                    <h3 class="text-white mt-n1">320.4k</h3>
                                    <div class="progress bg-black-transparent-5 mb-2" style="height: 6px">
                                        <div class="progrss-bar progress-bar-striped bg-white" style="width: 80%"></div>
                                    </div>
                                    <div class="text-white-transparent-8 mb-4"><i class="fa fa-caret-up"></i> 20% increase <br />compare to last week</div>
                                    <div><a href="#" class="text-white d-flex align-items-center text-decoration-none">View report <i class="fa fa-chevron-right ms-2 text-white-transparent-5"></i></a></div>
                                </div>
                                <!-- END card-body -->
                            </div>
                            <!-- END card -->
                        </div>
                        <!-- BEGIN col-6 -->
                    </div>
                    <!-- END row -->
                </div>
                <!-- END col-6 -->
            </div>
            <!-- END row -->
            
            <!-- BEGIN row -->
            
            <!-- END row -->
            
            <!-- BEGIN row -->
            <div class="row">
                <!-- BEGIN col-6 -->
                <div class="col-xl-6">
                    <!-- BEGIN card -->
                    <div class="card mb-3">
                        <!-- BEGIN card-body -->
                        <div class="card-body">
                            <div class="d-flex align-items-center mb-4">
                                <div class="flex-grow-1">
                                    <h5 class="mb-1">Bestseller</h5>
                                    <div class="fs-13px">Top 3 product sales this week</div>
                                </div>
                                <a href="#" class="text-decoration-none">See All</a>
                            </div>
                            
                            <!-- product-1 -->
                            <div class="d-flex align-items-center mb-3">
                                <div class="d-flex align-items-center justify-content-center me-3 width-50 height-50">
                                    <img src="https://payviame.com/wp-content/uploads/2020/12/mtn.jpg" alt="" class="ms-100 mh-100" />
                                </div>
                                <div class="flex-grow-1">
                                    <div>
                                        <div class="text-primary fs-10px font-weight-600">TOP SALES</div>
                                        <div class="text-dark font-weight-600">MTN Airtime</div>
                                        <div class="fs-13px">N5,000</div>
                                    </div>
                                </div>
                                <div class="ps-3 text-center">
                                    <div class="text-dark font-weight-600">382</div>
                                    <div class="fs-13px">sales</div>
                                </div>
                            </div>
                            
                            <!-- product-2 -->
                            <div class="d-flex align-items-center mb-3">
                                <div class="d-flex align-items-center justify-content-center me-3 width-50 height-50">
                                    <img src="https://payviame.com/wp-content/uploads/2020/12/phcn.jpg" alt="" class="ms-100 mh-100" />
                                    </div>
                                <div class="flex-grow-1">
                                    <div>
                                        <div class="text-dark font-weight-600">Electricity Bill</div>
                                        <div class="fs-13px">N50,000</div>
                                    </div>
                                </div>
                                <div class="ps-3 text-center">
                                    <div class="text-dark font-weight-600">102</div>
                                    <div class="fs-13px">sales</div>
                                </div>
                            </div>
                            
                            <!-- product-3 -->
                            <div class="d-flex align-items-center mb-3">
                                <div class="d-flex align-items-center justify-content-center me-3 width-50 height-50">
                                    <img src="https://payviame.com/wp-content/uploads/2020/12/9mobile.jpg" alt="" class="ms-100 mh-100" />
                                </div>
                                <div class="flex-grow-1">
                                    <div>
                                        <div class="text-dark font-weight-600">9 Mobile</div>
                                        <div class="fs-13px">N45,000</div>
                                    </div>
                                </div>
                                <div class="ps-3 text-center">
                                    <div class="text-dark font-weight-600">75</div>
                                    <div class="fs-13px">sales</div>
                                </div>
                            </div>
                            
                    
                            
                            <!-- product-5 -->
                            <div class="d-flex align-items-center">
                                <div class="d-flex align-items-center justify-content-center me-3 width-50 height-50">
                                    <img src="https://payviame.com/wp-content/uploads/2020/12/glo.jpg" alt="" class="ms-100 mh-100" />
                                </div>
                                <div class="flex-grow-1">
                                    <div>
                                        <div class="text-dark font-weight-600">Glo</div>
                                        <div class="fs-13px">N6,500</div>
                                    </div>
                                </div>
                                <div class="ps-3 text-center">
                                    <div class="text-dark font-weight-600">59</div>
                                    <div class="fs-13px">sales</div>
                                </div>
                            </div>
                        </div>
                        <!-- END card-body -->
                    </div>
                    <!-- END card -->
                </div>
                <!-- END col-6 -->
                
                <!-- BEGIN col-6 -->
                <div class="col-xl-6">
                    <!-- BEGIN card -->
                    <div class="card">
                        <!-- BEGIN card-body -->
                        <div class="card-body">
                            <div class="d-flex align-items-center mb-2">
                                <div class="flex-grow-1">
                                    <h5 class="mb-1">Wallet Transactions</h5>
                                    <div class="fs-13px">Latest transaction history</div>
                                </div>
                                
                            </div>
                            
                            <!-- BEGIN table-responsive -->
                            <div class="table-responsive mb-n2">
                                <table class="table table-borderless mb-0">
                                    <thead>
                                        <tr class="text-dark">
                                            <th class="ps-0">No</th>
                                            <th>Order Details</th>
                                            <th class="text-center">Type</th>
                                            <th class="text-end pe-0">Amount</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
                                        $i=0;
                                        foreach( $wallet_txns as $wallet_txn){
                                            $i++;
                                        ?>
                                        <tr>
                                            <td class="ps-0"><?php echo $i;?>
                                            <td>
                                                <div class="d-flex align-items-center">
                                                    
                                            
                                                        
                                                    <div class="ms-3 flex-grow-1">
                                                        <div class="font-weight-600 text-dark">Wrallo Wallet </div>
                                                        <div class="fs-13px">
                                                            <?php 
                                                            $timeStamp=$wallet_txn->txn_date;
                                                            echo date( "m/d/Y", strtotime($timeStamp));?>
</div>
                                                    </div>
                                                </div>
                                            </td>
                                            <?php if($wallet_txn->txn_type=="CREDIT"){?>
                                            <td class="text-center"><span class="badge bg-success-transparent-2 text-success" style="min-width: 60px;">Credit</span></td>
                                            <td class="text-end pe-0"><?php echo $wallet_txn->amount;?></td>
                                        <?php }else
                                        {
                                            ?>
                                               <td class="text-center"><span class="badge bg-success-transparent-2 text-danger" style="min-width: 60px;">Credit</span></td>
                                            <td class="text-end pe-0"><?php echo $wallet_txn->amount;?></td>
                                            <?php
                                        }
                                      ?>
                                        </tr>
                                    <?php }

                                ?>
                                        
                                    </tbody>
                                </table>
                            </div>
                            <!-- END table-responsive -->
                        </div>
                        <!-- END card-body -->
                    </div>
                    <!-- END card -->
                </div>
                <!-- END col-6 -->
            </div>
            <!-- END row -->
        </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\hp\wrallo\resources\views\home.blade.php ENDPATH**/ ?>