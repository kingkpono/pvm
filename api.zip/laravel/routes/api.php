<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/
Route::group([
    'middleware' => 'api',
    'prefix' => 'auth'

], function ($router) {
    Route::post('/login', 'AuthController@login');
    Route::post('/register', 'AuthController@register');
  
     Route::post('/logout', 'AuthController@logout');
    Route::post('/reset-password', 'AuthController@changePassword');
    Route::post('/refresh', 'AuthController@refresh');
    Route::get('/user-profile', 'AuthController@userProfile')->middleware("verified");  
    Route::put('/edit-profile', 'AuthController@updateProfile');      
    Route::put('/create-pin', 'AuthController@createPin'); 
    Route::put('/change-pin', 'AuthController@changePin'); 
    Route::post('/change-photo', 'AuthController@changePhoto');
    Route::post('/validate-pin', 'AuthController@validatePin');
    Route::post('/password/email','Auth\ForgotPasswordController@sendResetLinkEmail');
    Route::post('/password/reset', 'Auth\ForgotPasswordController@reset');


});




Route::get('email/verify/{id}', 'Auth\VerificationApiController@verify')->name('verificationapi.verify');
Route::get('email/resend', 'Auth\VerificationApiController@resend')->name('verificationapi.resend');

Route::post('/buy-airtime', 'TransactionController@paymentAdvice');
Route::post('/buy-data-1', 'TransactionController@getDataPaymentItems');
Route::post('/buy-tv', 'TransactionController@paymentAdvice2');
Route::post('/buy-electricity', 'TransactionController@paymentAdviceElect');
Route::post('/bet', 'TransactionController@paymentAdviceBet');
Route::post('/buy-internet', 'TransactionController@paymentAdviceInternet');



Route::get('/airtime-billers', 'TransactionController@getAirtimeBillers');

Route::get('/tv-items/{billerid}', 'TransactionController@paymentItems');
Route::get('/electric-items/{billerid}', 'TransactionController@paymentItems');
Route::get('/create-voucher/{billerId}', 'TransactionController@paymentItems');

Route::get('/bet-items/{billerid}', 'TransactionController@paymentItems');
Route::get('/internet-items/{billerid}', 'TransactionController@paymentItems');
Route::get('/wallet-balance', 'TransactionController@getWalletBalance');
Route::post('/credit-wallet', 'TransactionController@creditWallet');
Route::post('/debit-wallet', 'TransactionController@debitWallet');



Route::post('/transfer', 'TransactionController@transfer');


Route::post('/buy-data-2', 'TransactionController@paymentAdviceData');
Route::get('/tv-billers', 'TransactionController@getTvBillers');


Route::get('/electric-billers', 'TransactionController@getElectricBillers');
Route::get('/bet-billers', 'TransactionController@getBetBillers');
Route::get('/internet-billers', 'TransactionController@getInternetBillers');


Route::get('/payment-items/{billerId}', 'TransactionController@paymentItems');

Route::get('/biller-categories', 'AirtelController@billerCategories');
Route::get('/airtel-billers', 'AirtelController@fetchAirtelBillers');
Route::get('/mtn-billers', 'AirtelController@fetchMtnBillers');

Route::get('/transactions', 'TransactionController@fetchTxns');



Route::post('/payment-advice', 'AirtelController@paymentAdvice');
Route::post('/validate-customer', 'TransactionController@validateCustomer');
Route::post('/verify-transaction', 'AuthController@verifyTxn');

